-- phpMyAdmin SQL Dump
-- version 2.11.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 26, 2010 at 10:33 PM
-- Server version: 4.1.22
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `freewalk_freewalks`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblareas1`
--

DROP TABLE IF EXISTS `tblareas1`;
CREATE TABLE IF NOT EXISTS `tblareas1` (
  `nlArea1ID` bigint(20) NOT NULL default '0',
  `tArea1Name` text NOT NULL,
  `tArea1Active` tinyint(4) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblareas1`
--

INSERT INTO `tblareas1` (`nlArea1ID`, `tArea1Name`, `tArea1Active`) VALUES
(3, 'Spain', 1),
(2, 'UK', 1),
(1, 'All Areas', 0),
(4, 'USA', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblareas2`
--

DROP TABLE IF EXISTS `tblareas2`;
CREATE TABLE IF NOT EXISTS `tblareas2` (
  `nlArea1ID` int(11) NOT NULL default '0',
  `nlArea2ID` bigint(20) NOT NULL default '0',
  `tArea2Name` text NOT NULL,
  `tArea2Active` tinyint(4) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblareas2`
--

INSERT INTO `tblareas2` (`nlArea1ID`, `nlArea2ID`, `tArea2Name`, `tArea2Active`) VALUES
(1, 1, 'All Areas', 0),
(2, 3, 'Scotland', 1),
(2, 4, 'Wales', 1),
(2, 5, 'Northern Ireland', 1),
(2, 2, 'England', 1),
(3, 6, 'Gran Canaria', 1),
(3, 7, 'Lanzarote', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblareas3`
--

DROP TABLE IF EXISTS `tblareas3`;
CREATE TABLE IF NOT EXISTS `tblareas3` (
  `nlArea2ID` int(11) NOT NULL default '0',
  `nlArea3ID` bigint(20) NOT NULL default '0',
  `tArea3Name` text NOT NULL,
  `tArea3Active` int(11) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblareas3`
--

INSERT INTO `tblareas3` (`nlArea2ID`, `nlArea3ID`, `tArea3Name`, `tArea3Active`) VALUES
(2, 2, 'Cumbria', 1),
(2, 3, 'Yorkshire', 1),
(1, 1, 'All Areas', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblareas4`
--

DROP TABLE IF EXISTS `tblareas4`;
CREATE TABLE IF NOT EXISTS `tblareas4` (
  `nlArea3ID` int(11) NOT NULL default '0',
  `nlArea4ID` bigint(20) NOT NULL default '0',
  `tArea4Name` text NOT NULL,
  `tArea4Active` int(11) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblareas4`
--

INSERT INTO `tblareas4` (`nlArea3ID`, `nlArea4ID`, `tArea4Name`, `tArea4Active`) VALUES
(2, 2, 'Lake District', 1),
(2, 3, 'Eden Valley', 1),
(3, 4, 'Yorkshire Dales', 1),
(3, 5, 'North York Moors', 1),
(1, 1, 'All Areas', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblmappingtypes`
--

DROP TABLE IF EXISTS `tblmappingtypes`;
CREATE TABLE IF NOT EXISTS `tblmappingtypes` (
  `nlMappingTypeID` bigint(20) NOT NULL default '0',
  `tMappingType` text NOT NULL,
  `nbtMappingTypeLive` tinyint(4) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmappingtypes`
--

INSERT INTO `tblmappingtypes` (`nlMappingTypeID`, `tMappingType`, `nbtMappingTypeLive`) VALUES
(2, '1:50,000 OS', 1),
(3, '1:25,000 OS', 1),
(1, 'All Types', 0),
(4, 'Digital - Very little Detail', 1),
(5, 'Varied', 1),
(6, 'Unknown', 1),
(7, 'None', 1),
(8, 'Digital - Lots of detail', 1),
(9, 'Hand-drawn - Lots of detail', 1),
(10, 'Hand-drawn - Very little Detail', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

DROP TABLE IF EXISTS `tblpages`;
CREATE TABLE IF NOT EXISTS `tblpages` (
  `btID` tinyint(4) NOT NULL default '0',
  `tPageName` text NOT NULL,
  `tPageShortName` text NOT NULL,
  `btDisplay` tinyint(4) NOT NULL default '0',
  `btOrder` smallint(6) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`btID`, `tPageName`, `tPageShortName`, `btDisplay`, `btOrder`) VALUES
(1, 'Home', 'index.php', 1, 1),
(4, 'Walk Book/Map Publishers', 'under.php', 1, 4),
(3, 'Pay Route Sites', 'payroutes.php?cbo_free_areas1=2&cbo_free_areas2=2&cbo_free_areas3=2&cbo_free_areas4=2', 1, 3),
(2, 'Free Route Sites', 'freeroutes.php?cbo_free_areas1=2&cbo_free_areas2=2&cbo_free_areas3=2&cbo_free_areas4=2', 1, 2),
(5, 'Walk Book/Map Shops', 'under.php', 1, 5),
(6, 'Gear Shops', 'under.php', 1, 6),
(7, 'Trail Organisers', 'under.php', 1, 7),
(8, 'Accomodation', 'under.php', 1, 8),
(9, 'Skill Courses', 'under.php', 1, 9),
(10, 'Pubs', 'under.php', 1, 10),
(11, 'GPS', 'under.php', 0, 11),
(12, 'Other Free Resources', 'under.php', 1, 11),
(13, 'About Us/Contact', 'under.php', 1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `tblroutesites`
--

DROP TABLE IF EXISTS `tblroutesites`;
CREATE TABLE IF NOT EXISTS `tblroutesites` (
  `nlID` bigint(20) NOT NULL default '0',
  `tRouteSiteName` text NOT NULL,
  `tRouteSiteURL` text NOT NULL,
  `nbtRouteSiteType` tinyint(4) NOT NULL default '0',
  `nbtRouteSiteAreaLevel` tinyint(4) NOT NULL default '0',
  `nlRouteSiteArea` bigint(20) NOT NULL default '0',
  `nbtMappingTypeID` tinyint(4) NOT NULL default '0',
  `nbtRouteSiteLive` tinyint(4) NOT NULL default '0',
  `tSiteEmail1` text NOT NULL,
  `tSiteEmail2` text NOT NULL,
  `tRouteSiteReview` longtext NOT NULL,
  PRIMARY KEY  (`nlID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblroutesites`
--

INSERT INTO `tblroutesites` (`nlID`, `tRouteSiteName`, `tRouteSiteURL`, `nbtRouteSiteType`, `nbtRouteSiteAreaLevel`, `nlRouteSiteArea`, `nbtMappingTypeID`, `nbtRouteSiteLive`, `tSiteEmail1`, `tSiteEmail2`, `tRouteSiteReview`) VALUES
(1, 'Walking World', 'http://www.walkingworld.com/', 3, 1, 2, 2, 1, '', '', 'An absolutely excellent, mainly UK routes site with thousands of pay routes, and a few free ones. Each route comes with a 1:50,000 OS Map, but even better - step by step pictures of the walk - brilliant!'),
(2, 'Walking Britain', 'http://www.walkingbritain.co.uk/', 2, 1, 2, 4, 1, '', '', 'One of the best! Thousands of detailed, free walks in all areas of the UK. Great photos, detailed descriptions, and so much more too. Only gripe is that mapping is very limited, though it does link to places where you can buy the relevant OS maps.'),
(3, 'Walking in England', 'http://www.walkinginengland.co.uk/', 2, 2, 2, 5, 1, '', '', 'Decent reference to thousands of free walks from other websites. Some dead links.'),
(4, 'theLakelandFells', 'http://www.leaney.org/', 2, 4, 2, 3, 1, '', '', 'One of the best Lakes sites. Although there are no route descriptions, Andrew Leaney provides detailed maps of his many walks, as well as excellent and inspirational photography. Go check it out now!'),
(5, 'go4awalk.com', 'http://www.go4awalk.com/', 4, 1, 2, 6, 1, '', '', 'An absolutely collosal site which covers many aspects of walking, and thousands of pay walks and checklists - wow!'),
(6, 'Yorkshire Walks', 'http://www.yorkshirewalks.org', 2, 3, 3, 2, 1, 'frank@yorkshirewalks.org', '', 'Amazing site covering all areas of the beautiful county of Yorkshire. Excellent routes, detailed route photography, and each route has Landranger 1:50000 OS maps. A must for every proud Yorkshireman - well done Frank.'),
(7, 'Walks In Yorkshire', 'http://www.daleswalks.co.uk/', 2, 4, 4, 6, 1, 'info@daleswalks.co.uk', '', 'More of a general site with a few Yorkshire Dales walks with photography and 1:50000 location maps (although the routes are not marked on). Some of these are user submitted. Lots of other useful info on this site though...'),
(8, 'Country Walking', 'http://www.countrywalkingroutes.co.uk/routes/', 3, 1, 2, 2, 1, 'support@lfto.com', '', 'A massive archive of walks first published in the UKs leadning walking magazine - Country Walking. Excellent routes, with Landranger mapping. This site has a sister site/magazine called Trail with some more demanding walks...'),
(9, 'GrabYourBoots.com', 'http://www.grabyourboots.com/', 2, 1, 2, 5, 1, '', '', 'Although purely links to other free sites, this is an interesting site which uses Microsoft Virtual Earth mapping to present free walks. The site also allows you to upload your own...'),
(10, 'Trail Routes', 'http://www.trailroutes.com/routes/default.asp', 3, 1, 2, 2, 1, 'support@lfto.com', '', 'Like it''s sister site ''Country Walking'', Trail offers high quality routes and Landranger mapping, originally published in the Trail magazine. These routes are much more challenging than "Country Walking" routes, including longer hikes and hill scrambles'),
(11, 'Moors Knowledge', 'http://www.yorkshiremoors.co.uk/walks.html', 2, 4, 5, 4, 1, '', '', 'A decent bank of North York Moors walks with decent digitally drawn maps - part of a bigger site on the area - worth a look'),
(12, 'Dales Trails', 'http://www.dalestrails.co.uk/index.htm', 2, 3, 3, 3, 1, 'arnold.underwood@dalestrails.freeserve.co.uk', '', 'A great resouce of mainly Yorkshire (with a handful of Peak District and foreign walks) routes put together by Arnold Underwood - well done!...There are long-distance routes which are the main focus and ''other walks'' which are kept in the "Walk with Underwood" section...'),
(13, 'John Dawson''s lake District Walks', 'http://www.lakedistrictwalks.com/ldwalks.html', 2, 4, 2, 4, 1, 'ldwalks@lakedistrictwalks.com', '', 'A selection of walks with reasonable descriptions and basic maps - but all free, so all good!'),
(14, 'David Hall - Lake District Walks', 'http://www.davidhalllakedistrictwalks.co.uk/', 2, 4, 2, 3, 1, 'david@davidhalllakedistrictwalks.co.uk', '', 'Amazing collection of Lakes walks, with Explorer mapping and nice photography. Route descriptions are limited, but that doesn''t detract from one of the best sites out there for the lakes - even has a guide that cross-references distance with ascent...'),
(15, 'The Walking Englishman', 'http://www.walkingenglishman.com/index.aspx', 2, 1, 2, 3, 1, '', '', 'Another great site with (mainly) Explorer mapping, but so much more (route cards, and photo slideshows) for the North of England and Scotland - top work....'),
(16, 'Walks In The Lake District', 'http://www.lakeswalks.co.uk/', 2, 1, 1, 5, 1, 'info@lakeswalks.co.uk', '', 'Selection of routes, many short and simple with links to on-line mapping'),
(17, 'Striding Edge', 'http://www.stridingedge.net/index.html', 2, 4, 2, 3, 1, '', '', 'Not to be confused with the walking film makers of the same name - another awesome bank of walks and Explorer maps, with detailed photos, but not detailed descriptions. One of the best!'),
(18, 'Lake District Walking', 'http://www.search-cumbria.com/lake-district/walks/', 2, 4, 2, 7, 1, '', '', 'Very simple site with a few basic walk descriptions and sadly no mapping'),
(19, 'Lake District Outdoors', 'http://www.lakedistrictoutdoors.co.uk/outdooractivities.cfm?id=57', 2, 4, 2, 8, 1, 'info@golakes.co.uk', '', 'A much-loved site, provided by Cumbria Tourism - lots of classic walks and nice mapping');

-- --------------------------------------------------------

--
-- Table structure for table `tblroutesitetypes`
--

DROP TABLE IF EXISTS `tblroutesitetypes`;
CREATE TABLE IF NOT EXISTS `tblroutesitetypes` (
  `niRouteSiteType` int(11) NOT NULL default '0',
  `tRouteSiteType` text NOT NULL,
  `nbtRouteSiteTypeLive` tinyint(4) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblroutesitetypes`
--

INSERT INTO `tblroutesitetypes` (`niRouteSiteType`, `tRouteSiteType`, `nbtRouteSiteTypeLive`) VALUES
(2, 'All routes free', 1),
(4, 'Must pay for all routes', 1),
(3, 'Must pay for most routes - a few are free', 1),
(1, 'All Types', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblsystemconfig`
--

DROP TABLE IF EXISTS `tblsystemconfig`;
CREATE TABLE IF NOT EXISTS `tblsystemconfig` (
  `tWebsiteName` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsystemconfig`
--

INSERT INTO `tblsystemconfig` (`tWebsiteName`) VALUES
('Free Walking Routes.co.uk');
