<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="CSS/freewalks.css" />
<?php include("common_elements/title.php"); ?>

</head>
<body>
<?php include("common_elements/header.php"); ?>

<table class=main border=0>
<tr>
<td class=left width=60%>

<table width=100% border=0>
<tr>
<td class=sub_heading_left>
There are <u>thousands</u> of <i>free</i> walking routes available on the web!
</td>
<td class=right>
<?php
//Connect to database

include 'common_elements/dataconn.php';


$result = mysqli_query($con,"SELECT tPageShortName FROM tblpages WHERE tPageName = 'Free Route Sites'");
echo "<a href=";
while($row = mysqli_fetch_array($result))
{
echo $row['tPageShortName'];
}
echo "><img src=index/freeroutes1.png alt='Free Routes' /></a>";
mysqli_close($con);
?>
</td>
</tr>
</table>

<p class=bold>Welcome to Free Walking Routes.co.uk - the directory that lists the best free walking resources on the Internet:<br>
<br>
- Free walking routes<br>
- Searchable by area and functionality<br>
- Reviewed by Free Walking Routes.co.uk<br>
- Links to many other great walking resources such as shops, accomodation, trail organisers, pubs etc.<br>
</p>
</td>

<td class=right width=40%>

<p class=center>
<p class=bold_large>Page Currently Under Construction!</p>
<img height=200 src="under/Under.png">
</p>
</td>
</tr>
</table>
<?php
include 'common_elements/copyright.php';

?>
</body>
</html>
