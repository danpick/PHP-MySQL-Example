<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="CSS/freewalks.css" />
<?php include("common_elements/title.php"); ?>

</head>
<body>
<?php include("common_elements/header.php"); ?>

<table class="main" border="0">
<tr>
<td class="left" width=60%>
<p class="sub_heading">Your Free Route Websites</p>
</td>
</tr>
</table>


<?php
//retrieve values from querystring
$area1=$_GET['cboareas1']; //This line is added to take care if your global variable is off
$area2=$_GET['cboareas2']; //This line is added to take care if your global variable is off
$area3=$_GET['cboareas3']; //This line is added to take care if your global variable is off
$area4=$_GET['cboareas4']; //This line is added to take care if your global variable is off
$maptype=$_GET['maptype']; //This line is added to take care if your global variable is off

//echo $area1.",".$area2.",".$area3.",".$area4.",".$maptype;

//connect to database
include 'common_elements/dataconn.php';

$someresults=0;

$ii=1;
//All Matching Area $i Sites that are completely free/partiallyfree/paysites
while($ii<4)
{
$ii++;
	switch ($ii)
	{
	case 4:
		$sitetype="<b><i>paysites</i></b>";
		break;
	case 3:
		$sitetype="paysites with <b><i>some free</i></b> walks";
		break;
	default:
		$sitetype="sites that are <b><i>completely free</i></b>";
		break;
	}
//echo $ii;
$i=4;
while($i>0)
{
	switch ($i)
	{
	case 4:
		$area=$area4;
		$level=4;
		break;
	case 3:
		$area=$area3;
		$level=3;
		break;
	case 2:
		$area=$area2;
		$level=2;
		break;
	default:
		$area=$area1;
		$level=1;
		break;
	}
	$i--;

	if(strlen($area)==0)
	{
	$area="1";	
	}

	if(isset($area) and strlen($area) > 0)
	{
	$sql1="SELECT tArea".$level."Name FROM tblareas".$level." WHERE nlArea".$level."ID=".$area;
	$sql2="SELECT * FROM tblroutesites WHERE nbtRouteSiteAreaLevel=".$level." AND nlRouteSiteArea=".$area." AND nbtRouteSiteLive=1 AND 			nbtRouteSiteType=".$ii;
	
//echo "<br>".$sql1;
//echo "<br>".$sql2;
	}
		if(isset($maptype) and strlen($maptype) > 0)
			{
		$sql2=$sql2." and nbtMappingTypeID=".$maptype;
		}

	$result1 = mysqli_query($con,$sql1);
	
	while($row = mysqli_fetch_array($result1))
	{
	$areaname=$row[0];
	}

	$result2 = mysqli_query($con,$sql2);
	
	//echo $sql2;

	$numResults2 = mysqli_num_rows($result2);	
	if ($numResults2 > 0) {
		$someresults=1;
 		echo "<table class=results border=0>";
 		echo "<tr>";
 	  	echo "<td>";
 		echo "All <b>".$areaname."</b> ".$sitetype;
 		echo "</td>";
 		echo "</tr>";
 		echo "</table>";
 		echo "<table class=results border=1>";
		echo "<tr>";
		echo "<td width=25%>";
		echo "<b>Site Name</b>";
		echo "</td>";
		echo "<td>";
		echo "<b>Site</b>";
		echo "</td>";
		echo "<td>";
		echo "<b>Notes</b>";
		echo "</td>";
		echo "<td width=25%>";
		echo "<b>Preview</b>";
		echo "</td>";
		echo "</tr>";	
 		while($row = mysqli_fetch_array($result2))
		{
		echo "<tr>";
		echo "<td>";
		echo $row[1];
		echo "</td>";
		echo "<td align=center>";
		echo "<a href=";
		echo $row[2];
		echo " target=_blank>Go</a>";
		echo "</td>";
		echo "<td>";
		echo $row[10];
		echo "</td>";
		echo "<td>";
		echo "<img src=routesites/".$row[0].".png>";
		echo "</td>";
		echo "</tr>"; 
		}
 		echo "</table>";
 		echo "<br>";	
	}
}
}


		if($someresults==0)
		{
 		echo "<table class=results border=0>";
 		echo "<tr>";
 	  	echo "<td>";
 		echo "<i>There are no sites that have walks for the area that you have selected. Please go <a href='freeroutes.php?cbo_free_areas1=2&cbo_free_areas2=2&cbo_free_areas3=2&cbo_free_areas4=2'>back</a> and select another area</i> ";
 		echo "</td>";
 		echo "</tr>";
 		echo "</table>";		
		}


mysqli_close($con);
?>
<?php
include 'common_elements/copyright.php';

?>
</body>
</html>

