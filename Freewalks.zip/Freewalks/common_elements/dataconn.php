<?php
//Connect to database
$con = mysqli_connect("localhost","root","","freewalk_freewalks");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
//mysql_select_db("freewalk_freewalks", $con);
?>