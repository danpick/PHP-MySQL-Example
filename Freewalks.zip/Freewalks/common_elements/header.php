<!--table to layout some common elements -->
<table class=page_top border=0>
<!--log-on status display-->
<tr>
<td class=logged_on>
Welcome, Guest User
</td>
</tr>
<!--heading with website name-->
<tr>
<td class=heading>

<?php
//connect to database
include 'dataconn.php';

//retrieve website name
$result = mysqli_query($con,"SELECT tWebSiteName FROM tblsystemconfig");
while($row = mysqli_fetch_array($result))
  {
  echo $row['tWebSiteName'];
  }
?>
</td>
</tr>
<!--scene picture-->
<tr>
<td>
<img src="common_elements/scene.png" alt="Scene" />
</td>
</tr>
</table>

<!--hyperlinks menu -->
<table class="page_top" border=0>
<tr>
<!--<td class=menu>
<a href=index.php>Home</a>
</td>-->
<?php
//retrieve website pages
$recordcount = 0;
$result = mysqli_query($con,"SELECT tPageName, tPageShortName FROM tblpages WHERE btDisplay = 1 ORDER BY btORDER ASC");
while($row = mysqli_fetch_array($result))
  {	
  if($recordcount==6)
  {
  echo "</tr><tr>";
  }
  echo "<td class=menu>";
  echo "<a href=./" . strtolower(str_ireplace(" ","_",$row['tPageShortName'])) .">";
  echo $row['tPageName'];
  echo "</a>";
  echo "</td>";
  $recordcount = $recordcount + 1;
  }
mysqli_close($con);
?>
<tr>
</table>

