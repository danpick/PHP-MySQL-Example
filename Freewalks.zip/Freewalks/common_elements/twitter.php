<script src="http://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 5,
  interval: 6000,
  width: 250,
  height: 250,
  theme: {
    shell: {
      background: '#0099ff',
      color: '#ffffff'
    },
    tweets: {
      background: '#fcfcfc',
      color: '#0099ff',
      links: '#2d07eb'
    }
  },
  features: {
    scrollbar: true,
    loop: false,
    live: true,
    hashtags: true,
    timestamp: true,
    avatars: false,
    behavior: 'all'
  }
}).render().setUser('free_walks').start();
</script>