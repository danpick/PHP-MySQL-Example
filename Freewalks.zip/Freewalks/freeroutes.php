<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="CSS/freewalks.css" />
<?php include("common_elements/title.php"); ?>

<script>
function reload(form){
var val=form.cbo_free_areas1.options[form.cbo_free_areas1.options.selectedIndex].value;
self.location='freeroutes.php?cbo_free_areas1=' + val //+ '&cbo_free_areas2=' + val2 +  '&cbo_free_areas3=' + val3 //+ '&cbo_free_areas4=' + val4;
}

function reload2(form){
var val=form.cbo_free_areas1.options[form.cbo_free_areas1.options.selectedIndex].value;
var val2=form.cbo_free_areas2.options[form.cbo_free_areas2.options.selectedIndex].value;
self.location='freeroutes.php?cbo_free_areas1=' + val + '&cbo_free_areas2=' + val2 //+  '&cbo_free_areas3=' + val3 //+ '&cbo_free_areas4=' + val4;
}

function reload3(form){
var val=form.cbo_free_areas1.options[form.cbo_free_areas1.options.selectedIndex].value;
var val2=form.cbo_free_areas2.options[form.cbo_free_areas2.options.selectedIndex].value;
var val3=form.cbo_free_areas3.options[form.cbo_free_areas3.options.selectedIndex].value;
self.location='freeroutes.php?cbo_free_areas1=' + val + '&cbo_free_areas2=' + val2 +  '&cbo_free_areas3=' + val3 //+ '&cbo_free_areas4=' + val4;
}

function reload4(form){
var val=form.cbo_free_areas1.options[form.cbo_free_areas1.options.selectedIndex].value;
var val2=form.cbo_free_areas2.options[form.cbo_free_areas2.options.selectedIndex].value;
var val3=form.cbo_free_areas3.options[form.cbo_free_areas3.options.selectedIndex].value;
var val4=form.cbo_free_areas4.options[form.cbo_free_areas4.options.selectedIndex].value;
self.location='freeroutes.php?cbo_free_areas1=' + val + '&cbo_free_areas2=' + val2 +  '&cbo_free_areas3=' + val3 + '&cbo_free_areas4=' + val4;
}

function reload5(form){
var val=form.cbo_free_areas1.options[form.cbo_free_areas1.options.selectedIndex].value;
var val2=form.cbo_free_areas2.options[form.cbo_free_areas2.options.selectedIndex].value;
var val3=form.cbo_free_areas3.options[form.cbo_free_areas3.options.selectedIndex].value;
var val4=form.cbo_free_areas4.options[form.cbo_free_areas4.options.selectedIndex].value;
var val5=form.cbo_free_maptypes.options[form.cbo_free_maptypes.options.selectedIndex].value;
self.location='freeroutes.php?cbo_free_areas1=' + val + '&cbo_free_areas2=' + val2 +  '&cbo_free_areas3=' + val3 + '&cbo_free_areas4=' + val4 + "&cbo_free_maptypes=" + val5;
}

</script>

</head>
<body>
<?php include("common_elements/header.php"); ?>

<table class="main" border="0">
<tr>
<td class="left" width=60%>
<p class="sub_heading">Free Route Websites</p>

<table border=0 width=100%>
<tr>
<td>
Show me free route sites that: 
</td>
<td>

</td>
</tr>
</table>
<br />

<table width="100%" border="0">

<?php
echo "<form method=post name=frm_free_routes action='freeroutes.php'>";
echo "<tr>";
echo "<td>cover the areas:";
echo "</td>";

//area 1
echo "<td><select name=cbo_free_areas1 onchange=reload(this.form)>";
//retrieve values from querystring
$area1=$_GET['cbo_free_areas1']; //This line is added to take care if your global variable is off
$area2=$_GET['cbo_free_areas2']; //This line is added to take care if your global variable is off
$area3=$_GET['cbo_free_areas3']; //This line is added to take care if your global variable is off
$area4=$_GET['cbo_free_areas4']; //This line is added to take care if your global variable is off
//$maptype=$_GET['cbo_free_maptypes']; //This line is added to take care if your global variable is off

include 'common_elements/dataconn.php';


//area 1
$result = mysqli_query($con,"SELECT nlArea1ID, tArea1Name FROM tblareas1 WHERE tArea1Active=1 ORDER BY tArea1Name ASC");
//echo "<option class=standard value='1'>All Areas</option>";
while($row = mysqli_fetch_array($result))
  {
  if ($row['nlArea1ID']==@$area1)
  		  {
		  	echo "<option selected class=standard value="; 
		  }
		  	else
		  {
		  	echo "<option class=standard value="; 
		  }
  echo $row['nlArea1ID'];
  echo ">"; 
  echo $row['tArea1Name']; 
  echo "</option>";
  }
echo "</select>";
echo "</td>";
echo "</tr>";

//////WALLPAPER CODE FOR NEXT 3 SECTION - COULD DO WITH TIDYING UP//////

//area 2
if(isset($area1) and strlen($area1) > 0)
{
	$result2 = mysqli_query($con,"SELECT nlArea2ID, tArea2Name FROM tblareas2 where tArea2Active=1 and nlArea1ID=$area1 ORDER BY tArea2Name ASC");
}
else
{
	$result2 = mysql_query("SELECT nlArea2ID, tArea2Name FROM tblareas2 where nlArea2ID < 1"); //dummy query
}
   echo "<tr>";
	echo "<td>";
	echo "</td>";
	echo "<td><select name=cbo_free_areas2";
	echo " onchange=\"reload2(this.form)\">";
	echo "<option class=standard value='1'>All Areas</option>";
	while($row = mysqli_fetch_array($result2))
  	{
  		echo "<option ";
  		if ($row['nlArea2ID']==@$area2)
		{
		echo "selected "; 			  	 		  	
		}
		echo "class=standard value=";
  		echo $row['nlArea2ID'];
  		echo ">";
  		echo $row['tArea2Name']; 
  		echo "</option>";
  	}
	echo "</select>";
	echo "</td>";
	echo "</tr>";

//area 3
if(isset($area2) and strlen($area2) > 0)
{
	$result3 = mysqli_query($con,"SELECT nlArea3ID, tArea3Name FROM tblareas3 where tArea3Active=1 and nlArea2ID=$area2 ORDER BY tArea3Name ASC");
}
else
{
	$result3 = mysql_query("SELECT nlArea3ID, tArea3Name FROM tblareas3 where nlArea3ID < 1"); //dummy query
}
echo "<tr>";
echo "<td>";
echo "</td>";
echo "<td><select name=cbo_free_areas3";
echo " onchange=\"reload3(this.form)\">";
echo "<option class=standard value='1'>All Areas</option>";
while($row = mysqli_fetch_array($result3))
{
	echo "<option ";
  	if ($row['nlArea3ID']==@$area3)
	{
	echo "selected "; 			  	 		  	
	}
	echo "class=standard value=";
  	echo $row['nlArea3ID'];
  	echo ">";
  	echo $row['tArea3Name']; 
  	echo "</option>";
}
echo $row['nlArea3ID'];	
echo ">";
echo $row['tArea3Name']; 
echo "</option>";
echo "</select>";
echo "</td>";
echo "</tr>";

	
//area 4
if(isset($area3) and strlen($area3) > 0)
{
	$result4 = mysqli_query($con,"SELECT nlArea4ID, tArea4Name FROM tblareas4 where tArea4Active=1 and nlArea3ID=$area3 ORDER BY tArea4Name ASC");
}
else
{
	$result4 = mysql_query("SELECT nlArea4ID, tArea4Name FROM tblareas4 where nlArea4ID < 1"); //dummy query
}
echo "<tr>";
echo "<td>";
echo "</td>";
echo "<td><select name=cbo_free_areas4";
echo " onchange=\"reload4(this.form)\">";
echo "<option class=standard value='1'>All Areas</option>";
while($row = mysqli_fetch_array($result4))
{
	echo "<option ";
  	if ($row['nlArea4ID']==@$area4)
	{
	echo "selected "; 			  	 		  	
	}
	echo "class=standard value=";
  	echo $row['nlArea4ID'];
  	echo ">";
  	echo $row['tArea4Name']; 
  	echo "</option>";
  	}
echo $row['nlArea4ID'];
echo ">";
ecHo $row['tArea4Name']; 
echo "</option>";
echo "</select>";
echo "</td>";
echo "</tr>";	

//map types
echo "<tr>";
echo "<td>with map types:";
echo "</td>";
echo "<td>";
echo "<select name=cbo_free_maptypes";
echo " onchange=\"reload5(this.form)\">";
$result5 = mysqli_query($con,"SELECT nlMappingTypeID, tMappingType FROM tblmappingtypes WHERE nbtMappingTypeLive=1 ORDER BY tMappingType ASC");
echo "<option class=standard value=''>All Types</option>";
while($row = mysqli_fetch_array($result5))
  {
  echo "<option "; 
  if ($row['nlMappingTypeID']==@$maptype)
  {
  echo "selected "; 			  	 		  	
  }
  echo "class=standard value="; 
  echo $row['nlMappingTypeID'];
  echo ">"; 
  echo $row['tMappingType']; 
  echo "</option>";
  }
echo "</select>";
echo "</td>";
echo "</tr>";

mysqli_close($con);
echo "</form>";
?>
</table>
<br>
<br>
<table width=100% border=0>
<tr>
<td align=center>
<?php
$qs="freeroutesresults.php?cboareas1=";
$qs=$qs.$area1;
$qs=$qs."&cboareas2=";
$qs=$qs.$area2;
$qs=$qs."&cboareas3=";
$qs=$qs.$area3;
$qs=$qs."&cboareas4=";
$qs=$qs.$area4;
$qs=$qs."&maptype=";
//$qs=$qs.$maptype;

echo "<form method=post name=frm_free_routes_go action=";
echo $qs;
echo ">";
?>
<input type="image" src=freeroutes/free_routes_go.png>
</form>
</td>
</tr>
</table>


</td>

<td class="right" width="40%">



</td>
</tr>
</table>
<?php
include 'common_elements/copyright.php';

?>
</body>
</html>

